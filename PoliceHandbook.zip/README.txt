Installation:
1. Move the "policehandbook" folder into your FiveM Server Directory > cfx-server-data-master > resources
2. Open your "server.cfg" file in your FiveM Server Directory > cfx-server-data-master
3. Add a new line as "start policehandbook".


Copyright & Usage:
© 2020 - London Studios - Do not redistibute, modify/change or reupload without my obtained permission. 
This may be used on public/private FiveM servers and used in videos published to websites, 
however the source files should not be redistributed. This is for non-commercial use.